import React from 'react';

function HomePage() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Welcome to the E-Commerce Store</h1>
      <p>Explore our products!</p>
    </div>
  );
}

export default HomePage;